let students = JSON.parse(localStorage.getItem("students")) || [];

const form = document.getElementById("studentForm");
const nameInput = document.getElementById("stuname");
const idInput = document.getElementById("stuid");
const classInput = document.getElementById("stuclass");
const rollInput = document.getElementById("sturoll");
const output = document.getElementById("studentTableBody");
let isEditing = false;
let editIndex = null;

// Initial render
renderTable();

form.addEventListener("submit", function (e) {
    e.preventDefault();

    const name = nameInput.value.trim();
    const id = idInput.value.trim();
    const stuClass = classInput.value.trim();
    const roll = rollInput.value.trim();

    if (name === "" || id === "" || stuClass === "" || roll === "") {
        alert("Please fill all fields.");
        return;
    }

    const student = { name, id, stuClass, roll };

    if (isEditing) {
        // Update existing student
        students[editIndex] = student;
        isEditing = false;
        editIndex = null;
    } else {
        // Add new student
        students.unshift(student);
    }

    localStorage.setItem("students", JSON.stringify(students));

    renderTable();

    // Clear inputs
    form.reset();
});

function renderTable() {
    output.innerHTML = "";

    students.forEach((student, index) => {
        const row = document.createElement("tr");

        row.innerHTML = `
            <td>${student.name}</td>
            <td>${student.id}</td>
            <td>${student.stuClass}</td>
            <td>${student.roll}</td>
            <td>
                <button class="edit-btn" data-index="${index}"><i class="fa-solid fa-pen-to-square"></i></button>
                <button class="delete-btn" data-index="${index}"><i class="fa-solid fa-trash"></i></button>
            </td>
        `;

        output.appendChild(row);
    });
}

output.addEventListener("click", function (e) {
    const editBtn = e.target.closest(".edit-btn");
    const deleteBtn = e.target.closest(".delete-btn");

    if (deleteBtn) {
        const index = deleteBtn.dataset.index;
        students.splice(index, 1);
        localStorage.setItem("students", JSON.stringify(students));
        renderTable();
    }

    if (editBtn) {
        editIndex = editBtn.dataset.index;
        const student = students[editIndex];

        nameInput.value = student.name;
        idInput.value = student.id;
        classInput.value = student.stuClass;
        rollInput.value = student.roll;

        isEditing = true;
    }
});